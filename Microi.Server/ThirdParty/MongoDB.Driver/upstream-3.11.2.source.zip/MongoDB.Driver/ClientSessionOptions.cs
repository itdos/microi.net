﻿/* Copyright 2017-present MongoDB Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

using System;
using MongoDB.Bson;
using MongoDB.Driver.Core.Bindings;
using MongoDB.Driver.Core.Operations;

namespace MongoDB.Driver
{
    /// <summary>
    /// Client session options.
    /// </summary>
    public class ClientSessionOptions
    {
        // public properties
        /// <summary>
        /// When true or unspecified, an application will read its own writes and subsequent
        /// reads will never observe an earlier version of the data.
        /// </summary>
        public bool? CausalConsistency { get; set; }

        /// <summary>
        /// Gets or sets the default transaction options.
        /// </summary>
        /// <value>
        /// The default transaction options.
        /// </value>
        public TransactionOptions DefaultTransactionOptions { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether snapshot reads are requested.
        /// </summary>
        /// <value>
        ///   <c>true</c> if snapshot reads are requested; otherwise, <c>false</c>.
        /// </value>
        public bool Snapshot { get; set;}

        /// <summary>
        /// Gets or sets the snapshot time. If set, Snapshot must be true.
        /// </summary>
        /// <value> The snapshot time. </value>
        public BsonTimestamp SnapshotTime { get; set; }

        // internal methods
        internal CoreSessionOptions ToCore(
            bool isImplicit = false,
            int maxAdaptiveRetries = RetryabilityHelper.OperationRetryBackpressureConstants.DefaultMaxRetries,
            bool enableOverloadRetargeting = false)
        {
            var isCausallyConsistent = CausalConsistency ?? !Snapshot;

            return new CoreSessionOptions(
                isCausallyConsistent: isCausallyConsistent,
                isImplicit: isImplicit,
                defaultTransactionOptions: DefaultTransactionOptions,
                isSnapshot: Snapshot,
                snapshotTime: SnapshotTime,
                maxAdaptiveRetries: maxAdaptiveRetries,
                enableOverloadRetargeting: enableOverloadRetargeting);
        }
    }
}

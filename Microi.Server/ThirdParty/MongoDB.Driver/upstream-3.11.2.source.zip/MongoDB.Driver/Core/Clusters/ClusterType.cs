/* Copyright 2013-present MongoDB Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

namespace MongoDB.Driver.Core.Clusters
{
    /// <summary>
    /// Represents the type of a cluster.
    /// </summary>
    public enum ClusterType
    {
        /// <summary>
        /// The type of the cluster is unknown.
        /// </summary>
        Unknown,

        /// <summary>
        /// The cluster is a standalone cluster.
        /// </summary>
        Standalone,

        /// <summary>
        /// The cluster is a replica set.
        /// </summary>
        ReplicaSet,

        /// <summary>
        /// The cluster is a sharded cluster.
        /// </summary>
        Sharded,

        /// <summary>
        /// The cluster is in a load balanced mode.
        /// </summary>
        LoadBalanced
    }
}

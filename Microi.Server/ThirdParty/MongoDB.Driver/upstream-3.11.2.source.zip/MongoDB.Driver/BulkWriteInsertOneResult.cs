﻿/* Copyright 2010-present MongoDB Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

using System;
using MongoDB.Bson;

namespace MongoDB.Driver
{
    /// <summary>
    /// Represents result of <see cref="BulkWriteInsertOneModel{TDocument}"/> operation.
    /// </summary>
    public class BulkWriteInsertOneResult
    {
        /// <summary>
        /// The id of the inserted document.
        /// </summary>
        [Obsolete("InsertedId is deprecated and will be removed in future versions. Use DocumentId instead.")]
        public BsonValue InsertedId
        {
            get => BsonValue.Create(DocumentId);
            init
            {
                DocumentId = value;
            }
        }

        /// <summary>
        /// The id of the inserted document.
        /// </summary>
        public object DocumentId { get; init; }
    }
}

/* ====================================================================
   Licensed To the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for Additional information regarding copyright ownership.
   The ASF licenses this file To You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed To in writing, software
   distributed under the License is distributed on an "AS Is" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================== */

/* ================================================================
 * About NPOI
 * Author: Tony Qu 
 * Author's email: tonyqus (at) gmail.com 
 * Author's Blog: tonyqus.wordpress.com.cn (wp.tonyqus.cn)
 * HomePage: http://www.codeplex.com/npoi
 * Contributors:
 * 
 * ==============================================================*/

using System;

using NPOI.HPSF.Wellknown;
using NPOI.POIFS.FileSystem;
using NPOI.Util;

namespace NPOI.HPSF
{

    /// <summary>
    /// Factory class To Create instances of {@link SummaryInformation},
    /// {@link DocumentSummaryInformation} and <see cref="PropertySet"/>.
    /// @author Rainer Klute 
    /// <a href="mailto:klute@rainer-klute.de">&lt;klute@rainer-klute.de&gt;</a>
    /// @since 2002-02-09
    /// </summary>
    public class PropertySetFactory
    {
        /**
         * <p>Creates the most specific <see cref="PropertySet"/> from an entry
         *  in the specified POIFS Directory. This is preferrably a {@link
         * DocumentSummaryInformation} or a {@link SummaryInformation}. If
         * the specified entry does not contain a property Set stream, an 
         * exception is thrown. If no entry is found with the given name,
         * an exception is thrown.</p>
         *
         * @param dir The directory to find the PropertySet in
         * @param name The name of the entry Containing the PropertySet
         * @return The Created <see cref="PropertySet"/>.
         * @if there is no entry with that name
         * @if the stream does not
         * contain a property Set.
         * @if some I/O problem occurs.
         * @exception EncoderFallbackException if the specified codepage is not
         * supported.
         */
        public static PropertySet Create(DirectoryEntry dir, String name)
        {
            DocumentInputStream inp = null;
            try
            {
                DocumentEntry entry = (DocumentEntry)dir.GetEntry(name);
                inp = new DocumentInputStream(entry);
                try
                {
                    return Create(inp);
                }
                catch(MarkUnsupportedException) { return null; }
            }
            finally
            {
                if(inp != null)
                    inp.Close();
            }
        }

        /// <summary>
        /// Creates the most specific <see cref="PropertySet"/> from an 
        /// <see cref="InputStream"/>. This is preferrably a <see cref="DocumentSummaryInformation"/>
        /// or a <see cref="SummaryInformation"/>. If
        /// the specified <see cref="InputStream"/> does not contain a property
        /// Set stream, an exception is thrown and the <see cref="InputStream"/>
        /// is repositioned at its beginning.
        /// </summary>
        /// <param name="stream">Contains the property set stream's data.</param>
        /// <returns>The Created <see cref="PropertySet"/>.</returns>
        public static PropertySet Create(InputStream stream)
        {
            stream.Mark(PropertySet.OFFSET_HEADER + ClassID.LENGTH+1);
            LittleEndianInputStream leis = new LittleEndianInputStream(stream);
            int byteOrder =  leis.ReadUShort();
            int format = leis.ReadUShort();
            _ = leis.ReadUInt();
            byte[] clsIdBuf = new byte[ClassID.LENGTH];
            leis.ReadFully(clsIdBuf);
            int sectionCount = (int)leis.ReadUInt();
        
            if (byteOrder != PropertySet.BYTE_ORDER_ASSERTION ||
                format != PropertySet.FORMAT_ASSERTION ||
                sectionCount < 0)
            {
                throw new NoPropertySetStreamException();
            }
        
            if (sectionCount > 0)
            {
                leis.ReadFully(clsIdBuf);
            }
            stream.Reset();
        
            ClassID clsId = new ClassID(clsIdBuf, 0);
            if (sectionCount > 0 && PropertySet.matchesSummary(clsId, SectionIDMap.SUMMARY_INFORMATION_ID))
            {
                return new SummaryInformation(stream);
            }
            else if (sectionCount > 0 && PropertySet.matchesSummary(clsId, SectionIDMap.DOCUMENT_SUMMARY_INFORMATION_ID))
            {
                return new DocumentSummaryInformation(stream);
            }
            else
            {
                return new PropertySet(stream);
            }
            //PropertySet ps = new PropertySet(stream);
            //try
            //{
            //    if(ps.IsSummaryInformation)
            //        return new SummaryInformation(ps);
            //    else if(ps.IsDocumentSummaryInformation)
            //        return new DocumentSummaryInformation(ps);
            //    else
            //        return ps;
            //}
            //catch(UnexpectedPropertySetTypeException ex)
            //{
            //    /* This exception will never be throws because we alReady checked
            //     * explicitly for this case above. */
            //    throw new InvalidOperationException(ex.Message, ex);
            //}
        }



        /// <summary>
        /// Creates a new summary information
        /// </summary>
        /// <returns>the new summary information.</returns>
        [Obsolete("Removed POI 3.17")]
        public static SummaryInformation CreateSummaryInformation()
        {
            MutablePropertySet ps = new MutablePropertySet();
            MutableSection s = (MutableSection)ps.FirstSection;
            s.FormatID = SectionIDMap.SUMMARY_INFORMATION_ID;
            try
            {
                return new SummaryInformation(ps);
            }
            catch(UnexpectedPropertySetTypeException ex)
            {
                /* This should never happen. */
                throw new HPSFRuntimeException(ex);
            }
        }

        /// <summary>
        /// Creates a new document summary information.
        /// </summary>
        /// <returns>the new document summary information.</returns>
        [Obsolete("Removed POI 3.17")]
        public static DocumentSummaryInformation CreateDocumentSummaryInformation()
        {
            MutablePropertySet ps = new MutablePropertySet();
            MutableSection s = (MutableSection)ps.FirstSection;
            s.FormatID = SectionIDMap.DOCUMENT_SUMMARY_INFORMATION_ID[0];
            try
            {
                return new DocumentSummaryInformation(ps);
            }
            catch(UnexpectedPropertySetTypeException ex)
            {
                /* This should never happen. */
                throw new HPSFRuntimeException(ex);
            }
        }

        public static SummaryInformation NewSummaryInformation()
        {
            return new SummaryInformation();
        }

        internal static DocumentSummaryInformation NewDocumentSummaryInformation()
        {
            return new DocumentSummaryInformation();
        }
    }
}
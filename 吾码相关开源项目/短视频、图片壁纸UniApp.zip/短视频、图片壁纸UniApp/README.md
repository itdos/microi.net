# 基于开源低代码平台Microi吾码的图片壁纸、短视频开源项目

## 在线预览
>* V1版本在线H5：[https://h5.jsnzk.com:1888](https://h5.jsnzk.com:1888)
>* V2版本在线H5：[https://h5.jsnzk.com:1999](https://h5.jsnzk.com:1999)

>* V2版本源码地址：[https://gitee.com/microi-net/douyin](https://gitee.com/microi-net/douyin) 

<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/pc1.jpeg" width="100%" style="border-radius: 10px;margin: 5px;">

# 前言
>* 使用【Microi吾码】低代码平台驱动的开源图片壁纸、短视频开源项目
>* 前端页面采用[图鸟模板-壁纸](https://ext.dcloud.net.cn/plugin?id=10699)
>* 短视频页面采用[短视频模版，高性能滑动，预加载，视频预览，多端覆盖](https://ext.dcloud.net.cn/plugin?id=5656)
>* 特别感谢以上两位原创作者的无私奉献

# 亮点
>* 通过低代码**数据引擎**聚合多平台图片、视频资源<font color="#FF0000">（支持自定义来源配置）</font>
>* 用户注册、短信验证码、用户登陆功能<font color="#FF0000">（低代码平台接口引擎实现）</font>
>* 会员开通（小程序支付、支付回调、退款申请、退款回调）<font color="#FF0000">（低代码平台接口引擎实现）</font>
>* 小程序Token自动以旧换新（自动登录）
>* 瀑布流等数据列表下拉加载更多
>* 轮播图骨架屏、数据列表骨架屏、热门精选骨架屏
>* 小程序一键授权获取手机号自动登陆、自动注册、自动绑定帐号<font color="#FF0000">（低代码平台接口引擎实现）</font>

# 后台试用地址、开源地址
>* 首页：[https://jsnzk.microios.com](https://jsnzk.microios.com)
>* <font color="#0000FF">演示帐号：demo &nbsp;&nbsp;&nbsp;&nbsp; 演示密码：demo123456</font>
>* Gitee开源地址：[https://gitee.com/microi-net/jsnzk](https://gitee.com/microi-net/jsnzk)
>* 官方CSDN文章：[https://microi.blog.csdn.net/article/details/144002079](https://microi.blog.csdn.net/article/details/144002079)

# 线上小程序、APP等
>APP内容更多、安卓、苹果、H5（有些可能挂了，不定期更新）

<!-- <img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/miniprogram.jpg" width="210px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/android-latest.png" width="210px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/h5.jsnzk.com-testflight.png" width="210px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/h5.jsnzk.com.png" width="210px" style="border-radius: 10px;margin: 5px;"> -->

# 移动端预览图

<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/1.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/3.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/5.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/7.png" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/9.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/11.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/12.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/13.png" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/15.png" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/17.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/19.jpeg" width="280px" style="border-radius: 10px;margin: 5px;">

# 网络较差时骨架屏

<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/21.png" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/23.png" width="280px" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/25.png" width="280px" style="border-radius: 10px;margin: 5px;">

# 后台管理系统预览图
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/pc2.jpeg" width="100%" style="border-radius: 10px;margin: 5px;">
<img src="https://os.microios.com:1120/jsnzk-public/jsnzk/img/upload/pc3.jpeg" width="100%" style="border-radius: 10px;margin: 5px;">


# 更新日志
>* v2.0.0（2024-11-24）
>* 继续维护，即将新增广告主

>* v1.0.7（2023-12-14）
>* 通过接口引擎驱动数据引擎，现在可在接口引擎中通过配置Selector对接数据源

>* v1.0.6（2023-12-06）
>* 兼容安卓apk并打包发布
>* 小程序、APP、H5 内容、分类数据隔离（某些内容仅在APP、H5中展示）
>* 修复一些bug


>* 数据库脱敏：

```sql
DELETE from diy_content;
update sys_config set SmsKey='',SmsSecret='',PayKey='',WxPayPrivateKey='',MiniProgramSecret='',APIv3SecretKey='',CertSerialNo='';
DELETE from Sys_User where Account <> 'admin' and Account <> 'demo';
update Sys_User set Pwd='zWN76zrkGpdOa5JH7ztU1A==';
DELETE from diy_vip_order;
DELETE from diy_usr_favorite;
DELETE from diy_watch_record;
DELETE from diy_important_log;
DELETE from microi_datalog;
```
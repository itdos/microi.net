/**
 * API 引擎断点调试入口文件
 * 
 * 🎯 使用方法：
 * 1. 修改下方的 targetFile 为要调试的文件
 * 2. 修改 params 为测试参数
 * 3. 在目标 .js 文件中设置断点
 * 4. 按 F5 启动调试（选择 "调试当前 API 引擎"）
 * 
 * 💡 提示：断点应该设置在 api-engines 目录下的目标文件中
 */

const { runApiEngine, V8 } = require('./debug-runner');
const path = require('path');

// ============================================
// ⚙️ 配置区域 - 修改这里
// ============================================

// 要调试的 API 引擎文件（相对于 api-engines 目录）
// 新路径结构：{OsClient}/{OsClientType}/{OsClientNetwork}/{Category}/{ApiEngineKey}.js
const targetFile = 'iTdos/Product/Internal/未分类/dns_sync_ip.js';

// 请求参数（模拟前端传入的参数）
const params = {
    Key: 'iTdos',  // 此接口需要的验证参数
    // JobParam: JSON.stringify({ Key: 'iTdos' })  // 如果从定时任务调用
};

// ============================================
// 🔧 可选：修改模拟配置
// ============================================

// 如果需要，可以在这里修改 V8 的模拟数据
// V8.OsClient = 'your-client';
// V8.OsClientModel.AlidnsKeyId = 'real-key-id';

// ============================================
// 🚀 执行调试
// ============================================

async function debug() {
    const filePath = path.join(__dirname, 'api-engines', targetFile);
    
    console.log('╔════════════════════════════════════════════════════════╗');
    console.log('║           V8 接口引擎 - 本地断点调试                    ║');
    console.log('╠════════════════════════════════════════════════════════╣');
    console.log('║ 📄 目标文件:', targetFile.padEnd(42) + '║');
    console.log('║ 💡 提示: 在目标文件中设置断点后按 F5 调试              ║');
    console.log('╚════════════════════════════════════════════════════════╝');
    console.log('');
    
    // ⬇️ 在这里设置断点，Step Into 可进入 runApiEngine
    const result = await runApiEngine(filePath, params);
    
    console.log('');
    console.log('╔════════════════════════════════════════════════════════╗');
    console.log('║                    调试完成                             ║');
    console.log('╚════════════════════════════════════════════════════════╝');
    
    return result;
}

// 运行
debug().catch(err => {
    console.error('❌ 调试失败:', err.message);
    process.exit(1);
});
